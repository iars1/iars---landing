export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '20%' }}>
      <h1>Bienvenido a iARS</h1>
      <p>Tu mundo. Tu ritmo.</p>
    </div>
  );
}